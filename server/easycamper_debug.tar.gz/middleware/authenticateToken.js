// middleware/authenticateToken.js
'use strict';

const jwt = require('jsonwebtoken');

module.exports = function authenticateToken(req, res, next) {
  // Prendo header in modo case‐insensitive
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  if (!authHeader) {
    return res.status(401).json({ error: 'Token mancante' });
  }

  // Se c’è il prefisso “Bearer ”, lo tolgo; altrimenti prendo tutto
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : authHeader.trim();

  if (!token) {
    return res.status(401).json({ error: 'Token mancante' });
  }

  try {
    // jwt.verify può lanciare eccezione
    const user = jwt.verify(token, process.env.JWT_SECRET);
    req.user = user;
    next();
  } catch (err) {
    console.error('❌ JWT non valido:', err);
    return res.status(401).json({ error: 'Token non valido' });
  }
};
