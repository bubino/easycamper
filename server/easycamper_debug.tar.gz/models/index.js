//-------------------------------------------------
// Factory di Sequelize + autoloader modelli
//-------------------------------------------------
const { Sequelize, DataTypes } = require('sequelize');
const fs   = require('fs');
const path = require('path');

// ---- seleziona il blocco config corretto ----
const env   = process.env.NODE_ENV || 'development';
const cfg   = require('../config/config')[env];

let sequelize;

// 1) se abbiamo DATABASE_URL (Heroku, docker-compose…) la usiamo
if (process.env.DATABASE_URL) {
  sequelize = new Sequelize(process.env.DATABASE_URL, {
    dialect: 'postgres',
    logging: false,
  });
} else {
  // 2) altrimenti usiamo SEMPRE il Postgres definito in config.js
  sequelize = new Sequelize(cfg.database, cfg.username, cfg.password, cfg);
}

// ---------- carico automaticamente tutti i file modello ----------
const db = {};
const modelsDir = __dirname;

fs.readdirSync(modelsDir)
  .filter(f => f !== 'index.js' && f.endsWith('.js'))
  .forEach(filename => {
    console.log(`📄 Caricamento modello: ${filename}`);
    const model = require(path.join(modelsDir, filename))(sequelize, DataTypes);
    db[model.name] = model;
  });

// ---------- relazioni (se definite) -------------------------------
Object.values(db).forEach(model => {
  if (typeof model.associate === 'function') model.associate(db);
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;
module.exports = db;
