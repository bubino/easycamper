'use strict';
const express = require('express');
const router  = express.Router();
const { Spot } = require('../models');
const authenticateToken = require('../middleware/authenticateToken');

// GET /spots
router.get('/', authenticateToken, async (req, res) => {
  try {
    const spots = await Spot.findAll({ where: { userId: req.user.id } });
    res.json(spots);
  } catch (err) {
    console.error('Errore in GET /spots:', err);
    res.status(500).json({ error: 'Errore del server' });
  }
});

// POST /spots
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      id,
      name,
      latitude,
      longitude,
      type,
      services,
      features,
      accessible,
      public: isPublic
    } = req.body;
    const spot = await Spot.create({
      id,
      userId: req.user.id,
      name,
      latitude,
      longitude,
      type,
      services,
      features,
      accessible,
      public: isPublic
    });
    res.status(201).json(spot);
  } catch (err) {
    console.error('Errore in POST /spots:', err);
    res.status(500).json({ error: 'Errore del server' });
  }
});

// full CRUD su /spots/:id (GET singolo, PUT, DELETE) rimane invariato

module.exports = router;
