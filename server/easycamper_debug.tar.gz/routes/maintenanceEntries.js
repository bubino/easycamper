'use strict';
const express = require('express');
const router  = express.Router();
const { MaintenanceEntry } = require('../models');
const authenticateToken = require('../middleware/authenticateToken');

// GET /maintenance
router.get('/', authenticateToken, async (req, res) => {
  try {
    const entries = await MaintenanceEntry.findAll({ where: { userId: req.user.id } });
    res.json(entries);
  } catch (err) {
    console.error('Errore in GET /maintenance:', err);
    res.status(500).json({ error: 'Errore del server' });
  }
});

// POST /maintenance
router.post('/', authenticateToken, async (req, res) => {
  try {
    // includo anche id e description
    const { id, date, type, description } = req.body;
    const entry = await MaintenanceEntry.create({
      id,
      userId: req.user.id,
      date,
      type,
      description
    });
    res.status(201).json(entry);
  } catch (err) {
    console.error('❌ Errore in POST /maintenance:', err);
    res.status(500).json({ error: 'Errore del server' });
  }
});

// full CRUD su /maintenance/:id rimane invariato

module.exports = router;
